package com.example.nirmal.pickupdrop;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Nirmal on 4/3/2017.
 */

public class dbhelper extends SQLiteOpenHelper {
    public static final String dbname="bus_time";
    public static final int dbver=1;
    public static final String tbname="details1";
    public static final String c1="id";
    public static final String c2="time";
    public static final String c3="name";
    public static final String c4="section";
    public static final String c5="contactno";

    public dbhelper(Context context) {
        super(context,"bus_time", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String s="create table "+tbname+"("+c1+" integer primary key autoincrement ,"+c2+" varchar ,"+c3+" varchar ,"+c4+" varchar ,"+c5+" varchar)";
        //give like create table student"(id integer p k,name text,total float)";
        db.execSQL(s);


    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists"+tbname);
        onCreate(db);

    }


}

