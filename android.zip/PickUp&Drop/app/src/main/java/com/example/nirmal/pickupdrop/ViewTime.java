package com.example.nirmal.pickupdrop;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ViewTime extends AppCompatActivity {
    TextView e1,e2,e3,e4;
    Button call;
    SQLiteDatabase db;
    dbhelper d;
    Context mc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_time);
        e1=(TextView)findViewById(R.id.txt1);
        e2=(TextView)findViewById(R.id.txt2);
        e3=(TextView)findViewById(R.id.txt3);
        e4=(TextView)findViewById(R.id.txt4);

        mc=this;
        call=(Button)findViewById(R.id.call);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phno=e4.getText().toString();
                Intent in2=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+phno));
                startActivity(in2);
            }
        });
        Intent in=getIntent();
        String vnm=in.getStringExtra("time");
        Toast.makeText(getApplicationContext(),vnm, Toast.LENGTH_LONG).show();

        d=new dbhelper(this);
        db=d.getWritableDatabase();

       // if (db != null) {
           // Toast.makeText(this, "not null", Toast.LENGTH_SHORT).show();
       // }

      Cursor cursor1 = db.rawQuery("SELECT * FROM details1 where time='"+vnm+"'", null);


       // Toast.makeText(mc,cursor1.getCount() +" hii",Toast.LENGTH_LONG).show();

        if(cursor1!=null) {
            cursor1.moveToFirst();

        String num=cursor1.getString(cursor1.getColumnIndex("time"));
        String name=cursor1.getString(cursor1.getColumnIndex("name"));
        String sr=cursor1.getString(cursor1.getColumnIndex("section"));
        String dn=cursor1.getString(cursor1.getColumnIndex("contactno"));


            //Toast.makeText(mc,"passed"+mid,Toast.LENGTH_LONG).show();

       e1.setText(num);
       e2.setText(name);
       e3.setText(sr);
       e4.setText(dn);
        }

    }
}



