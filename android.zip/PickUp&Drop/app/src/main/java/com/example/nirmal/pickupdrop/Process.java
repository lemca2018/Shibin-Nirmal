package com.example.nirmal.pickupdrop;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.function.LongToIntFunction;

public class Process extends AppCompatActivity {
    private EditText et1, et2, et3, et4, et5;
    private Button add;
    private Button viewall;
    private Button delete;
    private Button update;


    SQLiteDatabase db;
    dbhelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process);

        et2 = (EditText) findViewById(R.id.et2);
        et3 = (EditText) findViewById(R.id.et3);
        et4 = (EditText) findViewById(R.id.et4);
        et5 = (EditText) findViewById(R.id.et5);


        add = (Button) findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add();
            }

        });


        viewall = (Button) findViewById(R.id.viewall);
        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewall();
            }

        });
        update = (Button) findViewById(R.id.update);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update();
            }

        });
        delete = (Button) findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete();
            }

        });


    }




    public void add() {

        if (( et2.getText().toString().trim().length() == 0) ||
                ( et3.getText().toString().trim().length() == 0) ||
                ( et4.getText().toString().trim().length() == 0) ||
                (et5.getText().toString().trim().length() == 0)) {
            showMessage("error","enter values");
            return;

        }
        mydb=new dbhelper(this);
        db=mydb.getWritableDatabase();
        String  time, name, section, contactno;

        time = et2.getText().toString();
        name = et3.getText().toString();
        section = et4.getText().toString();
        contactno = et5.getText().toString();
        ContentValues values = new ContentValues();

        values.put(dbhelper.c2,time);
        values.put(dbhelper.c3,name);
        values.put(dbhelper.c4,section);
        values.put(dbhelper.c5,contactno);
        db.insert(dbhelper.tbname,null,values);
        /*values.put(dbhelper.c1, Float.parseFloat(time));
        values.put(dbhelper.c2, name);
        values.put(dbhelper.c3, Integer.parseInt(contactno));*/

        showMessage("success","rcd added");

        clearText();
    }
    public void delete()
    {
        if (et2.getText().toString().trim().length() == 0 )
        {
            showMessage("error", "enter values");
            return;
        }
        Cursor c=db.rawQuery("select * from details1 where time='"+et2.getText()+"'",null);
        if(c.moveToFirst())
        {
            db.execSQL("delete from details1 where time='" + et2.getText() + "'");
            showMessage("success", "rcd deleted");
        }
        else
        {
            showMessage("error", "invaild id");
        }
        clearText();
    }



    public void viewall() {
        mydb = new dbhelper(this);
        db = mydb.getWritableDatabase();
        Cursor c = db.query("details1",null,null,null,null,null,null);

        if (c.getCount() == 0)

        {


            showMessage("Error", "No records found");

            return;

        }

        StringBuffer buffer = new StringBuffer();

        while (c.moveToNext())

        {
            buffer.append(" id: " + c.getString(0) + "\n");
            buffer.append(" time: " + c.getString(1) + "\n");

            buffer.append("name: " + c.getString(2) + "\n");
            buffer.append(" section: " + c.getString(3) + "\n");

            buffer.append("contactno: " + c.getString(4) + "\n\n");

        }

        showMessage("bus Details", buffer.toString());
    }

    public void update() {
        Cursor c = db.rawQuery("SELECT * FROM details1 WHERE time='" + et1.getText() + "'", null);

        if (c.moveToFirst())

        {

            db.execSQL("UPDATE details1 SET name='" + et2.getText() + "',contactno='" + et3.getText() + "' WHERE time='" + et1.getText() + "'");
            showMessage("success", "Record Modified");
        }
        clearText();
    }







    public void showMessage(String title,String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        // et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");
        et5.setText("");
    }
}
