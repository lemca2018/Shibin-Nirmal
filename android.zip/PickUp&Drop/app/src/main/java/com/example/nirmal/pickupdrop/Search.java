package com.example.nirmal.pickupdrop;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import com.example.nirmal.pickupdrop.dbhelper;

import java.util.ArrayList;

public class Search extends AppCompatActivity {
    ListView lv;
    ArrayList<String> list = new ArrayList<String>();
    ArrayList<Integer> listid = new ArrayList<Integer>();
    Context mcontext;
    private dbhelper dbHelp;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        lv=(ListView)findViewById(R.id.lv);
        mcontext = this;

        try {
            dbhelper dbHelp = new dbhelper(mcontext);
            SQLiteDatabase db = dbHelp.getWritableDatabase();

            Cursor cursor = db.query(dbhelper.tbname, new String[]{dbhelper.c1, dbhelper.c2}, null, null, null, null, null, null);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                int c = cursor.getCount();
                for (int i = 0; i < c; i++) {
                    int id = cursor.getInt(cursor.getColumnIndex(dbhelper.c1));
                    String nm = cursor.getString(cursor.getColumnIndex(dbhelper.c2));
                    list.add(nm);
                    listid.add(id);
                    cursor.moveToNext();

                }
                ArrayAdapter<String> ada = new ArrayAdapter<String>(mcontext, android.R.layout.simple_list_item_1, list);
                lv.setAdapter(ada);

                //to display details of each item
                //clicking on an item-> go to the next activity(viewStudentActivity), use intent
                //pass values through intent using putExtra()
                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @
                            Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent in=new Intent(Search.this,ViewTime.class);

                        in.putExtra("id",String.valueOf(position));
                        in.putExtra("time", (String) parent.getItemAtPosition(position));

                        startActivity(in);
                    }
                });

            }

        }catch(SQLiteException e){
            Toast.makeText(this,"problem",Toast.LENGTH_SHORT).show();
        }
    }

}
